package com.infocolmeia;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

/*
Projeto: PAP – Prova de Aptidão Profissional
Curso: Técnico de Informática – Sistemas 2018/2021
Autor: Rodrigo Pires
Script: Código da classe PassRecovery.java
Data: 2 de março de 2021
*/

public class PassRecovery extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pass_recovery);
    }
}